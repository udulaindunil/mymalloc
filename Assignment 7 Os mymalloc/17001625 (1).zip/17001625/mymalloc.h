
void *MyMalloc(int);
void MyFree(void*);
void Display(void*);
void MemoryReport();
